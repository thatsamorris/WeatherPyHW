

```python
import pandas as pd
import random
import numpy as np
from citipy import citipy
import requests
import json 
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.patches as mpatches
import datetime
from config import api_key
%matplotlib inline

now = datetime.datetime.now()
date = now.strftime("%Y-%m-%d")
```


```python
location_df = pd.DataFrame()
location_df['latitude'] = [np.random.uniform(-90, 90) for x in range(1500)]
location_df['longitude'] = [np.random.uniform(-180, 180) for x in range(1500)]

city_list = []
country_list = []
for index, row in location_df.iterrows():
    city = citipy.nearest_city(row['latitude'], row['longitude']).city_name
    country = citipy.nearest_city(row['latitude'], row['longitude']).country_code
    city_list.append(city)
    country_list.append(country)
location_df['city'] = city_list
location_df['country code'] = country_list
```


```python
city_df = location_df.drop_duplicates('city')
city_df = city_df.set_index('city')
city_df['temperature F'] = ""
city_df['humidity %'] = ""
city_df['wind speed mph'] = ""
city_df['cloudiness %'] = ""
city_df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>latitude</th>
      <th>longitude</th>
      <th>country code</th>
      <th>temperature F</th>
      <th>humidity %</th>
      <th>wind speed mph</th>
      <th>cloudiness %</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>saint george</th>
      <td>33.624541</td>
      <td>-52.186872</td>
      <td>bm</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>bluff</th>
      <td>-59.968601</td>
      <td>158.932115</td>
      <td>nz</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>cayenne</th>
      <td>7.021873</td>
      <td>-47.224933</td>
      <td>gf</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>new norfolk</th>
      <td>-65.053606</td>
      <td>138.201147</td>
      <td>au</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <th>hithadhoo</th>
      <td>-21.949108</td>
      <td>85.403747</td>
      <td>mv</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </tbody>
</table>
</div>




```python
counter = 1
for index, row in city_df.iterrows():
    url = f'http://api.openweathermap.org/data/2.5/weather?q={index}&appid={api_key}&units=imperial'
    city_data = requests.get(url).json()
    try:
        temp = city_data['main']['temp'] 
        humidity = city_data['main']['humidity'] 
        wind = city_data['wind']['speed']
        cloudiness = city_data['clouds']['all']
        city_df.set_value(index,'temperature F', temp)
        city_df.set_value(index,'humidity %', humidity)
        city_df.set_value(index,'wind speed mph', wind)
        city_df.set_value(index,'cloudiness %', cloudiness)
        text_file = open("cities_gathered.txt", "a+",  newline="\n")
        text_file.write(f' data gathered for city #{counter} {index} from {url} \n')
        text_file.close()
    except: 
        print(f' no data gathered for city #{counter} {index} from {url}')
        text_file = open("null_cities.txt", "a+",  newline="\n")
        text_file.write(f' no data gathered for city #{counter} {index} from {url} \n')
        text_file.close()
    counter += 1 
```

    C:\Users\thats\AppData\Local\Continuum\anaconda3\lib\site-packages\ipykernel_launcher.py:10: FutureWarning: set_value is deprecated and will be removed in a future release. Please use .at[] or .iat[] accessors instead
      # Remove the CWD from sys.path while we load stuff.
    C:\Users\thats\AppData\Local\Continuum\anaconda3\lib\site-packages\ipykernel_launcher.py:11: FutureWarning: set_value is deprecated and will be removed in a future release. Please use .at[] or .iat[] accessors instead
      # This is added back by InteractiveShellApp.init_path()
    C:\Users\thats\AppData\Local\Continuum\anaconda3\lib\site-packages\ipykernel_launcher.py:12: FutureWarning: set_value is deprecated and will be removed in a future release. Please use .at[] or .iat[] accessors instead
      if sys.path[0] == '':
    C:\Users\thats\AppData\Local\Continuum\anaconda3\lib\site-packages\ipykernel_launcher.py:13: FutureWarning: set_value is deprecated and will be removed in a future release. Please use .at[] or .iat[] accessors instead
      del sys.path[0]
    

     no data gathered for city #20 rolim de moura from http://api.openweathermap.org/data/2.5/weather?q=rolim de moura&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #33 bengkulu from http://api.openweathermap.org/data/2.5/weather?q=bengkulu&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #66 tumannyy from http://api.openweathermap.org/data/2.5/weather?q=tumannyy&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #70 kopyevo from http://api.openweathermap.org/data/2.5/weather?q=kopyevo&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #75 taolanaro from http://api.openweathermap.org/data/2.5/weather?q=taolanaro&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #87 bargal from http://api.openweathermap.org/data/2.5/weather?q=bargal&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #94 ayios kirikos from http://api.openweathermap.org/data/2.5/weather?q=ayios kirikos&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #103 berbera from http://api.openweathermap.org/data/2.5/weather?q=berbera&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #104 mys shmidta from http://api.openweathermap.org/data/2.5/weather?q=mys shmidta&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #114 louisbourg from http://api.openweathermap.org/data/2.5/weather?q=louisbourg&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #129 nizhneyansk from http://api.openweathermap.org/data/2.5/weather?q=nizhneyansk&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #155 satitoa from http://api.openweathermap.org/data/2.5/weather?q=satitoa&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #156 raga from http://api.openweathermap.org/data/2.5/weather?q=raga&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #157 labutta from http://api.openweathermap.org/data/2.5/weather?q=labutta&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #188 camana from http://api.openweathermap.org/data/2.5/weather?q=camana&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #189 illoqqortoormiut from http://api.openweathermap.org/data/2.5/weather?q=illoqqortoormiut&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #190 sorvag from http://api.openweathermap.org/data/2.5/weather?q=sorvag&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #193 tapaua from http://api.openweathermap.org/data/2.5/weather?q=tapaua&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #194 toliary from http://api.openweathermap.org/data/2.5/weather?q=toliary&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #195 halalo from http://api.openweathermap.org/data/2.5/weather?q=halalo&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #212 mentok from http://api.openweathermap.org/data/2.5/weather?q=mentok&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #245 bac lieu from http://api.openweathermap.org/data/2.5/weather?q=bac lieu&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #252 macaboboni from http://api.openweathermap.org/data/2.5/weather?q=macaboboni&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #258 belushya guba from http://api.openweathermap.org/data/2.5/weather?q=belushya guba&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #267 samusu from http://api.openweathermap.org/data/2.5/weather?q=samusu&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #272 yunjinghong from http://api.openweathermap.org/data/2.5/weather?q=yunjinghong&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #294 safwah from http://api.openweathermap.org/data/2.5/weather?q=safwah&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #297 dzhusaly from http://api.openweathermap.org/data/2.5/weather?q=dzhusaly&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #302 attawapiskat from http://api.openweathermap.org/data/2.5/weather?q=attawapiskat&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #306 bandar-e torkaman from http://api.openweathermap.org/data/2.5/weather?q=bandar-e torkaman&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #312 ngukurr from http://api.openweathermap.org/data/2.5/weather?q=ngukurr&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #315 grand river south east from http://api.openweathermap.org/data/2.5/weather?q=grand river south east&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #334 marmaron from http://api.openweathermap.org/data/2.5/weather?q=marmaron&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #337 palabuhanratu from http://api.openweathermap.org/data/2.5/weather?q=palabuhanratu&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #341 urumqi from http://api.openweathermap.org/data/2.5/weather?q=urumqi&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #348 tsihombe from http://api.openweathermap.org/data/2.5/weather?q=tsihombe&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #349 barentsburg from http://api.openweathermap.org/data/2.5/weather?q=barentsburg&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #359 skalistyy from http://api.openweathermap.org/data/2.5/weather?q=skalistyy&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #376 sentyabrskiy from http://api.openweathermap.org/data/2.5/weather?q=sentyabrskiy&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #379 asau from http://api.openweathermap.org/data/2.5/weather?q=asau&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #413 santarem from http://api.openweathermap.org/data/2.5/weather?q=santarem&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #427 tsentralnyy from http://api.openweathermap.org/data/2.5/weather?q=tsentralnyy&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #446 rawannawi from http://api.openweathermap.org/data/2.5/weather?q=rawannawi&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #449 andenes from http://api.openweathermap.org/data/2.5/weather?q=andenes&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #455 bolshegrivskoye from http://api.openweathermap.org/data/2.5/weather?q=bolshegrivskoye&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #460 olafsvik from http://api.openweathermap.org/data/2.5/weather?q=olafsvik&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #468 vaitupu from http://api.openweathermap.org/data/2.5/weather?q=vaitupu&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #482 maarianhamina from http://api.openweathermap.org/data/2.5/weather?q=maarianhamina&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #483 kamenskoye from http://api.openweathermap.org/data/2.5/weather?q=kamenskoye&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #488 fort saint john from http://api.openweathermap.org/data/2.5/weather?q=fort saint john&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #516 aflu from http://api.openweathermap.org/data/2.5/weather?q=aflu&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #595 tabiauea from http://api.openweathermap.org/data/2.5/weather?q=tabiauea&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #603 samalaeulu from http://api.openweathermap.org/data/2.5/weather?q=samalaeulu&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
     no data gathered for city #606 el wasta from http://api.openweathermap.org/data/2.5/weather?q=el wasta&appid=880045f7d8ffa29a81409cfca0336f8d&units=imperial
    


```python

city_df = city_df[city_df['temperature F'] != ""]
city_df.head()
city_df['latitude'].dtype
```




    dtype('float64')




```python

colors = []
for latitude in city_df['latitude']:
    if latitude > 0:
        color = 'blue'
        colors.append(color)
    else:
        color = 'red'
        colors.append(color)
city_df['color'] = colors
city_df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>latitude</th>
      <th>longitude</th>
      <th>country code</th>
      <th>temperature F</th>
      <th>humidity %</th>
      <th>wind speed mph</th>
      <th>cloudiness %</th>
      <th>color</th>
    </tr>
    <tr>
      <th>city</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>saint george</th>
      <td>33.624541</td>
      <td>-52.186872</td>
      <td>bm</td>
      <td>73.4</td>
      <td>73</td>
      <td>3.36</td>
      <td>40</td>
      <td>blue</td>
    </tr>
    <tr>
      <th>bluff</th>
      <td>-59.968601</td>
      <td>158.932115</td>
      <td>nz</td>
      <td>44.66</td>
      <td>82</td>
      <td>2.71</td>
      <td>12</td>
      <td>red</td>
    </tr>
    <tr>
      <th>cayenne</th>
      <td>7.021873</td>
      <td>-47.224933</td>
      <td>gf</td>
      <td>80.6</td>
      <td>83</td>
      <td>5.82</td>
      <td>0</td>
      <td>blue</td>
    </tr>
    <tr>
      <th>new norfolk</th>
      <td>-65.053606</td>
      <td>138.201147</td>
      <td>au</td>
      <td>46.4</td>
      <td>65</td>
      <td>12.75</td>
      <td>40</td>
      <td>red</td>
    </tr>
    <tr>
      <th>hithadhoo</th>
      <td>-21.949108</td>
      <td>85.403747</td>
      <td>mv</td>
      <td>82.19</td>
      <td>100</td>
      <td>19.71</td>
      <td>76</td>
      <td>red</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Temperature (F) vs. Latitude
plt.scatter(city_df['latitude'], city_df['temperature F'], edgecolors = 'black', color = city_df['color'])
plt.grid()
plt.title(f'Temperature (F) vs. Latitude on {date} Color-Coded by Hemisphere')
plt.xlabel('Latitude')
plt.xlim(-95, 95, 25)
plt.ylim(0, 120, 25)
plt.ylabel('Temperature (F)')
red_patch = mpatches.Patch(color='red', label='Southern')
blue_patch = mpatches.Patch(color='blue', label='Northern')
plt.legend(handles=[red_patch, blue_patch], framealpha=0.2)

```




    <matplotlib.legend.Legend at 0x1d3491cf080>




![png](output_6_1.png)



```python
plt.scatter(city_df['latitude'], city_df['humidity %'], edgecolors = 'black', color = city_df['color'])
plt.title(f'City Humidity % VS. Latitude on {date} Color-Coded by Hemisphere')
plt.xlabel('Latitude')
plt.ylabel('Humidity %')
plt.grid()
plt.xlim(-95, 95, 25)
plt.ylim(0, 105, 20)
red_patch = mpatches.Patch(color='red', label='Southern')
blue_patch = mpatches.Patch(color='blue', label='Northern')
plt.legend(handles=[red_patch, blue_patch], framealpha=0.2)
```




    <matplotlib.legend.Legend at 0x1d349258860>




![png](output_7_1.png)



```python
plt.scatter(city_df['latitude'], city_df['cloudiness %'], edgecolors = 'black', color = city_df['color'])
plt.title(f'City Cloudiness(%) VS. Latitude on {date} Color-Coded by Hemisphere')
plt.xlabel('Latitude')
plt.ylabel('Cloudiness %')
plt.grid()
plt.xlim(-95, 95)
plt.ylim(-5, 105)
red_patch = mpatches.Patch(color='red', label='Southern')
blue_patch = mpatches.Patch(color='blue', label='Northern')
plt.legend(handles=[red_patch, blue_patch], framealpha=0.2)
```




    <matplotlib.legend.Legend at 0x1d3492c7898>




![png](output_8_1.png)



```python
plt.scatter(city_df['latitude'], city_df['wind speed mph'], edgecolors = 'black', color = city_df['color'])
plt.xlim(-95, 95)
plt.ylim(-5, 50)
plt.grid()
plt.title(f'City Wind Speed VS. Latitude on {date} Color-Coded by Hemisphere')
plt.xlabel('Latitude')
plt.ylabel('Wind Speed (MPH)')
red_patch = mpatches.Patch(color='red', label='Southern')
blue_patch = mpatches.Patch(color='blue', label='Northern')
plt.legend(handles=[red_patch, blue_patch], framealpha=0.2)
```




    <matplotlib.legend.Legend at 0x1d34933ee80>




![png](output_9_1.png)


1) Windspeeds are Relatively constant around the globe 
2) Max temperature generally rises as one approaches the equator and drops the further one get from it. 
3) Cloudiness is unpredictible in relation to Latitude. 
4) Humidity is everywhere. 
